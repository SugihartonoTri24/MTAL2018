<?php
error_reporting(E_ALL ^ (E_NOTICE | E_WARNING));
$conn = mysql_connect("localhost","root","");
mysql_select_db("mahasiswa");
$q = mysql_query("select * from biodata order by nim asc ");
$response["data"] = array();
while ($a = mysql_fetch_array($q)){
 $output = array();
 $output["nama"]=$a["nama"];
 $output["nim"]=$a["nim"];
 array_push($response["data"], $output);
}
echo json_encode($response);
?>