<?php
	$con=mysqli_connect("localhost","root", "","mahasiswa");

if (mysqli_connect_errno($con)){
	echo"Failed to connect to Mysql: " .mysqli_connect_error();
}
$username = $_POST['username'];
$password = $_POST['password'];
$result = mysqli_query($con, "SELECT * FROM tbl_user where username = '$username' and password ='$password'");
$row = mysqli_fetch_array($result);
$data = $row[0];

if ($data){
	echo 2;
} else {
	echo 0;
}
mysqli_close($con);
?>