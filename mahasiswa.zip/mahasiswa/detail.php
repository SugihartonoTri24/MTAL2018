<?php
error_reporting(E_ALL ^ (E_NOTICE | E_WARNING));
$conn = mysql_connect("localhost","root","");
mysql_select_db("mahasiswa");
$q = mysql_query("select * from biodata where nim='".$_GET[nim]."'");
$response["mahasiswa"] = array();
while ($a = mysql_fetch_array($q)){
 $output = array(); 
 $output["nim"]=$a["nim"];
 $output["nama"]=$a["nama"];
 $output["prodi"]=$a["prodi"];
 array_push($response["mahasiswa"], $output);
}
echo json_encode($response);
?>