<?php

$conn = mysql_connect("localhost","root","");
mysql_select_db("mahasiswa"); 

$NIM = $_POST['nim'];
$NAMA= $_POST['nama'];
$PRODI = $_POST['prodi'];
 
header('Content-Type: text/xml');
 
$query = "insert into biodata (nim, nama, prodi) values ('$NIM','$NAMA','$PRODI')";

$hasil = mysql_query($query);
if($hasil){
 $response["success"] = "1";
    $response["message"] = "Data sukses diinput";
    echo json_encode($response);
} else{
 $response["success"] = "0";
    $response["message"] = "Maaf , terjadi kesalahan";
 // echoing JSON response
    echo json_encode($response);
}
?>