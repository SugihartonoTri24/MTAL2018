package com.example.persiapanuas;

import java.util.ArrayList;
import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;
import android.os.Bundle;
import android.app.Activity;
import android.view.Menu;
import android.view.View;
import android.widget.*;
import android.content.Intent;


public class TambahActivity extends Activity {
	EditText nim, nama, prodi;
	 Intent i;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_tambah);
		
	Button btn_back;
        
        btn_back=(Button) findViewById(R.id.btn_back);
        btn_back.setOnClickListener(new View.OnClickListener() {
        	public void onClick(View v){
        		 finish();
              	 Intent a = new Intent();
                 a.setClassName("com.example.persiapanuas", "com.example.persiapanuas.MenuActivity");
                 startActivity(a);

        	}
        }); 
        
		
		nim = (EditText) findViewById(R.id.nim);
		nama = (EditText) findViewById(R.id.nama);
		prodi = (EditText) findViewById(R.id.prodi);

	}

	public void simpan (View View) {
		 String nim1 = nim.getText().toString();
		 String nama1 = nama.getText().toString();
		 String prodi1 = prodi.getText().toString();
		 
		 // TODO Auto-generated method stub
		 ArrayList<NameValuePair> postParameters = new ArrayList<NameValuePair>();
		 postParameters.add(new BasicNameValuePair("nim", nim1));
		 postParameters.add(new BasicNameValuePair("nama", nama1));	
		 postParameters.add(new BasicNameValuePair("prodi", prodi1));
		 
		 String response = null;
		 try { 
			 response = CustomHttpClient.executeHttpPost("http://10.0.2.2/insert/Simpan.php", postParameters);
			 String res = response.toString();
			 res = res.trim();
			 res = res.replaceAll("\\s+","");
			 if (res.equals("0"))
			 {
				 Toast.makeText(getApplicationContext(),"Data Sudah Tersimpan" , Toast.LENGTH_LONG).show();
              			 
			 }
			 else {
				 Toast.makeText(getApplicationContext(),"Data Sudah Tersimpan Ke Server" , Toast.LENGTH_LONG).show();

				 Intent i = new Intent(this, MenuActivity.class);
				 startActivity(i);

				 nim.setText("");
				 nama.setText("");
				 prodi.setText("");
			 }
		 } catch (Exception e) {
			 nim.setText(e.toString());
		 }
	 }
	}
