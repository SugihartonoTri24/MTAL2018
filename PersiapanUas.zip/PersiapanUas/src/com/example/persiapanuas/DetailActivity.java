package com.example.persiapanuas;

import java.util.ArrayList;
import java.util.HashMap;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.os.AsyncTask;
import android.os.Bundle;
import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.view.View;
import android.widget.Button;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.SimpleAdapter;
public class DetailActivity extends Activity {
	 ListView lv;
	 ProgressDialog pDialog;
	 JSONArray contacts = null;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_detail);
		lv=(ListView)findViewById(R.id.list);
        new AmbilData().execute();
        
        Button btn_back;
        btn_back=(Button) findViewById(R.id.back);
        btn_back.setOnClickListener(new View.OnClickListener() {
        	public void onClick(View v){
        		finish();
             	 Intent x = new Intent();
                 x.setClassName("com.example.persiapanuas", "com.example.persiapanuas.LihatActivity");
                 startActivity(x);
        	}
        });
   

    }


  public class AmbilData extends AsyncTask<String, String, String> {
   
  ArrayList<HashMap<String, String>> contactList = new ArrayList<HashMap<String, String>>();
  String nama, nim, Prodi;

  
  @Override
  protected void onPreExecute() {
   super.onPreExecute();
   pDialog = new ProgressDialog(DetailActivity.this);
   pDialog.setMessage("Loading Data...");
   pDialog.setIndeterminate(false);
   pDialog.setCancelable(false);
   pDialog.show();
  }

  @Override
  protected String doInBackground(String... arg0) {
  
	Bundle extras = getIntent().getExtras();
  String nim1 = extras.getString("tf_nim");
  String url = "http://10.0.2.2/insert/detail.php?nim="+nim1;

  JSONParser jParser = new JSONParser();

   JSONObject json = jParser.getJSONFromUrl(url);
   
   try {
    contacts = json.getJSONArray("mahasiswa");

    for (int i = 0; i < contacts.length(); i++) {
     JSONObject c = contacts.getJSONObject(i);
     HashMap<String, String> map = new HashMap<String, String>();
     
     String nama = c.getString("nama").trim();
     String nim = c.getString("nim").trim();
     String prodi = c.getString("prodi").trim();
     
     map.put("nama", nama);
     map.put("nim", nim);
     map.put("prodi", prodi);
    
    contactList.add(map);
    }

   } catch (JSONException e) {
    
    
   }

   return null;
  }

  @Override
  protected void onPostExecute(String result) {
   // TODO Auto-generated method stub
	  
   super.onPostExecute(result);
   
   pDialog.dismiss();
   
   ListAdapter adapter2 = new SimpleAdapter(getApplicationContext(),
     contactList, R.layout.detail_biodata,
     new String[] { "nama", "nim", "prodi" }, new int[] { R.id.nama, R.id.nim, R.id.prodi });

   lv.setAdapter(adapter2);
   

  }
  

 }
}
