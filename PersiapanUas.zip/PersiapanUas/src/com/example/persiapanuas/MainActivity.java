package com.example.persiapanuas;

import java.util.ArrayList;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;
import android.os.Bundle;
import android.app.Activity;
import android.view.Menu;
import android.view.View;
import android.widget.*;
import android.content.Intent;;

public class MainActivity extends Activity {
	EditText username;
	EditText password;
	EditText n1;
	Intent i;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		
		username = (EditText) findViewById(R.id.username);
		password = (EditText) findViewById(R.id.password);

	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

	
	public void masuk (View View){
		String user = username.getText().toString();
	String pwd =password.getText().toString();

	//TODO Auto-generated method stub
	ArrayList<NameValuePair> postParameters = new ArrayList<NameValuePair>();

	postParameters.add(new BasicNameValuePair("username",user));
	postParameters.add(new BasicNameValuePair("password",pwd));

	String response = null;
	try{
		response = CustomHttpClient.executeHttpPost("http://10.0.2.2/mahasiswa/login.php",postParameters);
		String res = response.toString();
	res = res.trim();
	res = res.replaceAll("\\s+","");
	if (res.equals("2"))
	{
	Intent i = new Intent (this,MenuActivity.class);
	startActivity(i);
	}
	else {
	Toast.makeText(getApplicationContext(),"Username atau Password salah !!!",Toast.LENGTH_SHORT).show();
	username.setText("");
	password.setText("");
	}
	}
	catch (Exception e){
	username.setText(e.toString());
	}
	}
}
